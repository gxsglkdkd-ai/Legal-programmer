import asyncio
import json

from rcon.source import Client as RconClient

from core.config import RconConfig
from utils.console import console


class MinecraftRcon:
    def __init__(self, config: RconConfig):
        self.config = config
        self._connected = False
        self._lock = asyncio.Lock()

    @property
    def connected(self) -> bool:
        return self._connected

    def _run_sync(self, command: str) -> str:
        # В rcon 2.x клиент работает как контекстный менеджер:
        # каждый вызов run() открывает соединение, авторизуется,
        # шлёт команду, читает ответ и закрывает соединение.
        with RconClient(
            host=self.config.host,
            port=self.config.port,
            passwd=self.config.password,
            timeout=self.config.timeout,
        ) as client:
            return client.run(command)

    async def connect(self) -> bool:
        try:
            await asyncio.to_thread(self._run_sync, "list")
            self._connected = True
            console.success(
                f"RCON подключен к {self.config.host}:{self.config.port}"
            )
            return True
        except Exception as e:
            console.error(f"Ошибка RCON подключения: {e}")
            self._connected = False
            return False

    async def send_command(self, command: str) -> str:
        async with self._lock:
            try:
                response = await asyncio.to_thread(
                    self._run_sync, command
                )
                self._connected = True
                text = (response or "").strip()
                return text or "✅ Команда выполнена (пустой ответ)"
            except Exception as e:
                console.error(f"RCON ошибка: {e}")
                self._connected = False
                return f"❌ RCON ошибка: {e}"

    async def send_chat(self, message: str, sender: str = "Remote") -> str:
        payload = [
            {
                "text": f"[{sender}] {message}",
                "color": "aqua",
            }
        ]
        command = "tellraw @a " + json.dumps(payload, ensure_ascii=False)
        return await self.send_command(command)

    async def send_raw(self, command: str) -> str:
        return await self.send_command(command)

    def disconnect(self):
        # В 2.x постоянного клиента нет — каждое соединение живёт внутри run().
        self._connected = False