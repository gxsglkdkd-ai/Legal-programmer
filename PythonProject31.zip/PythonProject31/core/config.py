import yaml
from dataclasses import dataclass


@dataclass
class RconConfig:
    host: str
    port: int
    password: str
    timeout: int


@dataclass
class WebServerConfig:
    host: str
    port: int
    cors_origins: list[str]


@dataclass
class DeviceRegistryConfig:
    file: str
    auto_register_host: bool
    cleanup_inactive_days: int


@dataclass
class LocalInputConfig:
    chat_key: str
    send_key: str
    focus_delay: float
    type_delay: float
    failsafe: bool
    use_pynput: bool


@dataclass
class AppConfig:
    name: str
    version: str


@dataclass
class Config:
    mode: str
    rcon: RconConfig
    web_server: WebServerConfig
    device_registry: DeviceRegistryConfig
    local_input: LocalInputConfig
    app: AppConfig

    @classmethod
    def load(cls, path: str = "config.yaml") -> "Config":
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        data.setdefault("mode", "local")
        data.setdefault(
            "local_input",
            {
                "chat_key": "t",
                "send_key": "enter",
                "focus_delay": 0.3,
                "type_delay": 0.01,
                "failsafe": True,
                "use_pynput": True,
            },
        )

        return cls(
            mode=data["mode"],
            rcon=RconConfig(**data["rcon"]),
            web_server=WebServerConfig(**data["web_server"]),
            device_registry=DeviceRegistryConfig(**data["device_registry"]),
            local_input=LocalInputConfig(**data["local_input"]),
            app=AppConfig(**data["app"]),
        )