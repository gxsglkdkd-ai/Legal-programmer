import asyncio
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from utils.device_info import DeviceInfo


@dataclass
class Device:
    id: str
    name: str
    type: str = "Unknown"
    ip: str = ""
    mac: str = ""
    registered_at: str = field(
        default_factory=lambda: datetime.now().isoformat()
    )
    last_seen: str = field(
        default_factory=lambda: datetime.now().isoformat()
    )
    is_active: bool = True
    metadata: dict = field(default_factory=dict)

    @classmethod
    def from_device_info(cls, info: DeviceInfo, device_type: str = "PC") -> "Device":
        return cls(
            id=info.short_id(),
            name=info.name,
            type=device_type,
            ip=info.ip,
            mac=info.mac,
        )

    def update_seen(self):
        self.last_seen = datetime.now().isoformat()
        self.is_active = True

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Device":
        return cls(**data)


class DeviceRegistry:
    def __init__(self, file_path: str, auto_register_host: bool = True):
        self.file_path = Path(file_path)
        self.auto_register_host = auto_register_host
        self._devices: dict[str, Device] = {}
        self._lock = asyncio.Lock()
        self._host_device: Optional[Device] = None

    async def load(self):
        async with self._lock:
            if self.file_path.exists():
                try:
                    content = await asyncio.to_thread(
                        self.file_path.read_text, encoding="utf-8"
                    )
                    data = json.loads(content)
                    self._devices = {
                        k: Device.from_dict(v) for k, v in data.items()
                    }
                except Exception:
                    self._devices = {}
            else:
                self._devices = {}

        if self.auto_register_host:
            await self._register_host()

    async def _register_host(self):
        info = DeviceInfo.detect()
        host_device = Device.from_device_info(info, "PC")
        host_device.metadata = {"auto_registered": True}
        registered = await self.register(host_device)
        self._host_device = registered

    async def _save_unlocked(self):
        data = {k: v.to_dict() for k, v in self._devices.items()}
        await asyncio.to_thread(
            self.file_path.write_text,
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    async def save(self):
        async with self._lock:
            await self._save_unlocked()

    async def register(self, device: Device) -> Device:
        async with self._lock:
            existing = self._devices.get(device.id)
            if existing:
                existing.name = device.name
                existing.type = device.type
                existing.ip = device.ip
                existing.metadata.update(device.metadata)
                existing.update_seen()
                device = existing
            else:
                self._devices[device.id] = device

            await self._save_unlocked()
            return device

    async def get(self, device_id: str) -> Optional[Device]:
        async with self._lock:
            device = self._devices.get(device_id)
            if device:
                device.update_seen()
                await self._save_unlocked()
            return device

    async def list_devices(self, active_only: bool = True) -> list[Device]:
        async with self._lock:
            devices = list(self._devices.values())
            if active_only:
                devices = [d for d in devices if d.is_active]
            return sorted(devices, key=lambda d: d.name.lower())

    async def cleanup_inactive(self, days: int):
        cutoff = datetime.now() - timedelta(days=days)
        async with self._lock:
            to_remove = [
                k
                for k, v in self._devices.items()
                if datetime.fromisoformat(v.last_seen) < cutoff
            ]
            for k in to_remove:
                del self._devices[k]
            if to_remove:
                await self._save_unlocked()

    @property
    def host_device(self) -> Optional[Device]:
        return self._host_device