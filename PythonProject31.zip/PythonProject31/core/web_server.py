import asyncio
import json
from pathlib import Path
from typing import Callable

from aiohttp import WSMsgType, web

from core.config import WebServerConfig
from core.device_registry import Device, DeviceRegistry
from core.input_injector import InputInjector
from core.rcon_client import MinecraftRcon
from utils.console import console


class WebServer:
    def __init__(
        self,
        config: WebServerConfig,
        registry: DeviceRegistry,
        rcon: MinecraftRcon,
        injector: InputInjector,
        mode_provider: Callable[[], str],
        static_dir: Path,
    ):
        self.config = config
        self.registry = registry
        self.rcon = rcon
        self.injector = injector
        self.mode_provider = mode_provider
        self.static_dir = Path(static_dir)
        self.app = web.Application()
        self._runner: web.AppRunner | None = None
        self._setup_routes()

    def _setup_routes(self):
        @web.middleware
        async def cors_middleware(request, handler):
            response = await handler(request)
            for origin in self.config.cors_origins:
                response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "Content-Type"
            return response

        self.app.middlewares.append(cors_middleware)

        self.app.router.add_get("/api/devices", self.handle_list_devices)
        self.app.router.add_post("/api/register", self.handle_register)
        self.app.router.add_post("/api/send", self.handle_send_message)
        self.app.router.add_get("/api/status", self.handle_status)
        self.app.router.add_options("/api/{tail:.*}", self.handle_options)
        self.app.router.add_get("/ws", self.handle_websocket)

        index_file = self.static_dir / "index.html"
        self.app.router.add_static(
            "/static/", path=str(self.static_dir), name="static"
        )
        self.app.router.add_get("/", lambda r: web.FileResponse(index_file))

    async def handle_options(self, request):
        return web.Response(status=200)

    async def handle_status(self, request):
        window = None
        if self.injector:
            window = await asyncio.to_thread(
                self.injector.find_minecraft_window
            )

        return web.json_response(
            {
                "status": "ok",
                "mode": self.mode_provider(),
                "rcon_connected": bool(self.rcon and self.rcon.connected),
                "mc_window_found": window is not None,
                "mc_window_title": window.title if window else None,
                "devices_count": len(await self.registry.list_devices()),
            }
        )

    async def handle_list_devices(self, request):
        devices = await self.registry.list_devices()
        return web.json_response(
            {"devices": [d.to_dict() for d in devices]}
        )

    async def handle_register(self, request):
        try:
            data = await request.json()
            device_id = data.get("device_id", "").upper()
            name = data.get("name", "Unknown")
            device_type = data.get("type", "Phone")

            if not device_id:
                return web.json_response(
                    {"error": "device_id required"}, status=400
                )

            device = Device(
                id=device_id,
                name=name,
                type=device_type,
                ip=request.remote or "",
                metadata={"registered_via": "api"},
            )

            registered = await self.registry.register(device)
            console.info(
                f"Зарегистрировано устройство: "
                f"{registered.name} ({registered.id})"
            )
            return web.json_response(
                {"success": True, "device": registered.to_dict()}
            )
        except Exception as e:
            console.error(f"Ошибка регистрации: {e}")
            return web.json_response({"error": str(e)}, status=500)

    async def handle_send_message(self, request):
        try:
            data = await request.json()
            device_id = data.get("device_id", "").upper()
            message = data.get("message", "").strip()

            if not device_id or not message:
                return web.json_response(
                    {"error": "device_id and message required"}, status=400
                )

            device = await self.registry.get(device_id)
            if not device:
                return web.json_response(
                    {"error": "Device not found"}, status=404
                )

            mode = self.mode_provider()

            if mode == "rcon":
                if not self.rcon or not self.rcon.connected:
                    return web.json_response(
                        {"error": "RCON не подключен"}, status=500
                    )

                response = await self.rcon.send_chat(
                    message, sender=device.name
                )
                ok = not response.startswith("❌")
                payload = {
                    "success": ok,
                    "mode": mode,
                    "detail": f"RCON: {response}",
                }
                if not ok:
                    payload["error"] = response
                    return web.json_response(payload, status=500)
                return web.json_response(payload)

            if mode == "local":
                result = await self.injector.send_chat_message(
                    message, sender=device.name
                )
                if not result.get("success"):
                    return web.json_response(
                        {"error": result.get("error")}, status=500
                    )
                return web.json_response(
                    {
                        "success": True,
                        "mode": mode,
                        "detail": result.get("detail", "OK"),
                    }
                )

            return web.json_response(
                {"error": f"Неизвестный режим: {mode}"}, status=500
            )
        except Exception as e:
            console.error(f"Ошибка отправки: {e}")
            return web.json_response({"error": str(e)}, status=500)

    async def handle_websocket(self, request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        console.info(f"WS подключение: {request.remote}")

        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    try:
                        data = json.loads(msg.data)
                        await self._handle_ws_message(ws, data)
                    except json.JSONDecodeError:
                        await ws.send_json({"error": "Invalid JSON"})
                elif msg.type == WSMsgType.ERROR:
                    console.error(f"WS ошибка: {ws.exception()}")
        finally:
            console.info(f"WS отключен: {request.remote}")

        return ws

    async def _handle_ws_message(self, ws, data: dict):
        action = data.get("action")
        mode = self.mode_provider()

        if action == "list":
            devices = await self.registry.list_devices()
            await ws.send_json(
                {"action": "list", "devices": [d.to_dict() for d in devices]}
            )

        elif action == "register":
            device_id = data.get("device_id", "").upper()
            name = data.get("name", "Unknown")
            device_type = data.get("type", "Phone")

            device = Device(
                id=device_id,
                name=name,
                type=device_type,
                metadata={"registered_via": "ws"},
            )
            registered = await self.registry.register(device)
            await ws.send_json(
                {"action": "registered", "device": registered.to_dict()}
            )

        elif action == "send":
            device_id = data.get("device_id", "").upper()
            message = data.get("message", "").strip()

            device = await self.registry.get(device_id)
            if not device:
                await ws.send_json(
                    {"action": "error", "message": "Device not found"}
                )
                return

            if mode == "rcon":
                if not self.rcon or not self.rcon.connected:
                    await ws.send_json(
                        {
                            "action": "error",
                            "message": "RCON не подключен",
                        }
                    )
                    return

                response = await self.rcon.send_chat(
                    message, sender=device.name
                )
                ok = not response.startswith("❌")
                await ws.send_json(
                    {
                        "action": "sent",
                        "response": response,
                        "mode": "rcon",
                        "result": {
                            "success": ok,
                            "detail": response,
                            "error": None if ok else response,
                        },
                    }
                )

            elif mode == "local":
                result = await self.injector.send_chat_message(
                    message, sender=device.name
                )
                await ws.send_json(
                    {"action": "sent", "result": result, "mode": "local"}
                )

            else:
                await ws.send_json(
                    {
                        "action": "error",
                        "message": f"Неизвестный режим: {mode}",
                    }
                )

        elif action == "status":
            window = None
            if self.injector:
                window = await asyncio.to_thread(
                    self.injector.find_minecraft_window
                )
            await ws.send_json(
                {
                    "action": "status",
                    "mode": mode,
                    "rcon_connected": bool(
                        self.rcon and self.rcon.connected
                    ),
                    "mc_window": window.title if window else None,
                }
            )
        else:
            await ws.send_json({"error": f"Unknown action: {action}"})

    async def start(self):
        self._runner = web.AppRunner(self.app)
        await self._runner.setup()
        site = web.TCPSite(
            self._runner, self.config.host, self.config.port
        )
        await site.start()
        console.success(
            f"Веб-сервер: http://{self.config.host}:{self.config.port}"
        )
        console.info(
            f"Веб-интерфейс для телефона: "
            f"http://<IP_ПК>:{self.config.port}"
        )

    async def stop(self):
        if self._runner:
            await self._runner.cleanup()