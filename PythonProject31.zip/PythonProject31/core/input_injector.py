import asyncio
import time
from typing import Optional

import pyautogui
import pygetwindow as gw
from pynput.keyboard import Controller as PynputController, Key

from core.config import LocalInputConfig
from utils.console import console

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.01


class InputInjector:
    def __init__(self, config: LocalInputConfig):
        self.config = config
        self.pynput_kb = PynputController()
        self._apply_config()

    def _apply_config(self):
        pyautogui.FAILSAFE = self.config.failsafe
        pyautogui.PAUSE = self.config.type_delay

    def find_minecraft_window(self) -> Optional[object]:
        patterns = [
            "Minecraft*",
            "Minecraft Launcher",
            "Badlion Client",
            "Lunar Client",
            "Feather Client",
            "PojavLauncher",
            "Minecraft Education Edition",
            "Minecraft for Windows",
            "MultiMC",
            "Prism Launcher",
            "ATLauncher",
            "CurseForge",
            "GDLauncher",
        ]

        for pattern in patterns:
            try:
                windows = gw.getWindowsWithTitle(pattern)
                for w in windows:
                    if w.visible and w.width > 200 and w.height > 150:
                        title_lower = w.title.lower()
                        if "launcher" in title_lower and "minecraft" not in title_lower:
                            continue
                        if "settings" in title_lower or "options" in title_lower:
                            continue
                        return w
            except Exception:
                continue
        return None

    def _press_key_pynput(self, key_str: str):
        key_map = {
            "enter": Key.enter,
            "return": Key.enter,
            "esc": Key.esc,
            "escape": Key.esc,
            "tab": Key.tab,
            "space": Key.space,
            "shift": Key.shift,
            "ctrl": Key.ctrl,
            "alt": Key.alt,
            "up": Key.up,
            "down": Key.down,
            "left": Key.left,
            "right": Key.right,
        }
        key = key_map.get(key_str.lower(), key_str)
        self.pynput_kb.press(key)
        self.pynput_kb.release(key)

    def _type_text_pynput(self, text: str):
        self.pynput_kb.type(text)

    def _press_key_pyautogui(self, key: str):
        pyautogui.press(key)

    def _type_text_pyautogui(self, text: str):
        pyautogui.write(text, interval=self.config.type_delay)

    def _send_chat_sync(self, message: str) -> dict:
        window = self.find_minecraft_window()
        if not window:
            return {
                "success": False,
                "error": "Окно Minecraft не найдено. Запустите игру и разверните окно.",
            }

        console.info(f"Окно: {window.title} [{window.width}x{window.height}]")

        try:
            if getattr(window, "isMinimized", False):
                window.restore()
                time.sleep(self.config.focus_delay)

            # 1. Всегда физически кликаем по центру окна MC.
            #    Это единственный надёжный способ отдать клавиатурный фокус GLFW.
            cx = window.left + window.width // 2
            cy = window.top + window.height // 2
            pyautogui.click(cx, cy)
            time.sleep(self.config.focus_delay + 0.2)

            # 2. Открываем чат.
            if self.config.use_pynput:
                self._press_key_pynput(self.config.chat_key)
            else:
                self._press_key_pyautogui(self.config.chat_key)
            time.sleep(0.3)

            # 3. Печатаем текст.
            text = message.replace("\r", " ").replace("\n", " ").strip()
            if self.config.use_pynput:
                self._type_text_pynput(text)
            else:
                self._type_text_pyautogui(text)
            time.sleep(0.15)

            # 4. Enter.
            if self.config.use_pynput:
                self._press_key_pynput(self.config.send_key)
            else:
                self._press_key_pyautogui(self.config.send_key)

            console.success(f"Сообщение введено: {text[:50]}")
            return {
                "success": True,
                "detail": "Введено локально через эмуляцию клавиатуры",
            }
        except pyautogui.FailSafeException:
            return {
                "success": False,
                "error": "Сработал FailSafe. Ввод отменен.",
            }
        except Exception as e:
            console.error(f"Ошибка ввода: {e}")
            return {
                "success": False,
                "error": f"Исключение при вводе: {e}",
            }

    async def send_chat_message(self, message: str, sender: str = "Remote") -> dict:
        return await asyncio.to_thread(self._send_chat_sync, message)