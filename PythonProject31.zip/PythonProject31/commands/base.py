from abc import ABC, abstractmethod
from typing import Any, Dict, List


class BaseCommand(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        ...

    @property
    def usage(self) -> str:
        return self.name

    @abstractmethod
    async def execute(self, args: List[str], context: Any) -> Dict:
        ...