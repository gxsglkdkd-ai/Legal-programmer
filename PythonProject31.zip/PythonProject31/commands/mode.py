from pathlib import Path
from typing import Dict, List

import yaml

from core.device_registry import Device
from utils.console import console


class ModeManager:
    def __init__(self, app):
        self.app = app

    async def send_as(self, device: Device, message: str) -> Dict:
        mode = self.app.config.mode

        if mode == "rcon":
            if not self.app.rcon or not self.app.rcon.connected:
                return {
                    "success": False,
                    "error": "RCON не подключен. Проверьте сервер и пароль.",
                }
            response = await self.app.rcon.send_chat(
                message, sender=device.name
            )
            if response.startswith("❌"):
                return {"success": False, "error": response}
            return {"success": True, "detail": f"RCON: {response}"}

        if mode == "local":
            if not self.app.injector:
                return {
                    "success": False,
                    "error": "InputInjector не инициализирован",
                }
            return await self.app.injector.send_chat_message(
                message, sender=device.name
            )

        return {"success": False, "error": f"Неизвестный режим: {mode}"}

    async def cmd_mode(self, args: List[str]):
        if not args:
            console.info(f"Текущий режим: {self.app.config.mode.upper()}")
            console.info("Доступные режимы: rcon, local")
            console.info("Использование: mode <rcon|local>")
            return

        new_mode = args[0].lower()
        if new_mode not in ("rcon", "local"):
            console.error(
                f"Неизвестный режим: {new_mode}. Доступно: rcon, local"
            )
            return

        if new_mode == self.app.config.mode:
            console.warning(f"Уже в режиме {new_mode}")
            return

        old_mode = self.app.config.mode
        self.app.config.mode = new_mode

        try:
            config_path = Path(
                getattr(self.app, "config_path", "config.yaml")
            )
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
            cfg["mode"] = new_mode
            with open(config_path, "w", encoding="utf-8") as f:
                yaml.dump(cfg, f, allow_unicode=True, sort_keys=False)
        except Exception as e:
            console.warning(f"Не удалось сохранить в config.yaml: {e}")

        console.success(
            f"Режим изменен: {old_mode.upper()} → {new_mode.upper()}"
        )

        if new_mode == "local":
            console.info(
                "💡 Убедитесь, что Minecraft запущен и окно развернуто!"
            )
            console.info("💡 Настройки клавиш: config.yaml → local_input")
        else:
            console.info(
                "💡 Требуется включенный RCON на сервере (server.properties)"
            )
            if self.app.rcon:
                ok = await self.app.rcon.connect()
                if ok:
                    console.success("RCON подключен")
                else:
                    console.warning(
                        "RCON не подключен. Проверьте config.yaml и сервер."
                    )