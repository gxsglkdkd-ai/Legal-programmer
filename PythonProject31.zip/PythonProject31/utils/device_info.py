import platform
import socket
import uuid
from dataclasses import dataclass


@dataclass
class DeviceInfo:
    name: str
    system: str
    release: str
    machine: str
    ip: str
    mac: str

    @classmethod
    def detect(cls) -> "DeviceInfo":
        hostname = socket.gethostname()

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except Exception:
            ip = "127.0.0.1"

        mac_hex = f"{uuid.getnode():012X}"
        mac = ":".join(
            mac_hex[i : i + 2] for i in range(0, 12, 2)
        )

        return cls(
            name=hostname,
            system=platform.system(),
            release=platform.release(),
            machine=platform.machine(),
            ip=ip,
            mac=mac.upper(),
        )

    def short_id(self) -> str:
        return self.mac.replace(":", "")[-8:].upper()

    def display_name(self) -> str:
        return f"{self.name} ({self.system} {self.release})"