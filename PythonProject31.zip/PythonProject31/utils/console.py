import builtins

from colorama import Back, Fore, Style, init

init(autoreset=True)


class Console:
    def __init__(self):
        self.Fore = Fore
        self.Style = Style
        self.Back = Back
        self.prefix = f"{Fore.CYAN}[MRC]{Style.RESET_ALL}"

    def _print(self, color: str, label: str, message: str):
        print(f"{self.prefix} {color}{label}{Style.RESET_ALL} {message}")

    def info(self, m):
        self._print(Fore.BLUE, "[INFO]", m)

    def success(self, m):
        self._print(Fore.GREEN, "[OK]", m)

    def warning(self, m):
        self._print(Fore.YELLOW, "[WARN]", m)

    def error(self, m):
        self._print(Fore.RED, "[ERROR]", m)

    def command(self, m):
        self._print(Fore.MAGENTA, "[CMD]", m)

    def input(self, prompt: str) -> str:
        try:
            return builtins.input(
                f"{self.prefix} {Fore.CYAN}{prompt}{Style.RESET_ALL} "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            raise KeyboardInterrupt

    def banner(self, title: str, version: str):
        print(
            f"\n{Fore.CYAN}{'═' * 55}\n"
            f"  {title} v{version}\n"
            f"  Minecraft Remote Chat Bridge\n"
            f"{'═' * 55}{Style.RESET_ALL}\n"
        )

    def help(self):
        print(f"\n{Fore.YELLOW}┌─ Команды ──────────────────────────────────────┐")
        print(f"│ {Fore.GREEN}reg list{Style.RESET_ALL}{Fore.YELLOW}              - Список устройств              │")
        print(f"│ {Fore.GREEN}register <name> [type]{Style.RESET_ALL}{Fore.YELLOW}   - Зарегистрировать хост (ПК)      │")
        print(f"│ {Fore.GREEN}send <id> <msg>{Style.RESET_ALL}{Fore.YELLOW}         - Отправить от устройства          │")
        print(f"│ {Fore.GREEN}chat <msg>{Style.RESET_ALL}{Fore.YELLOW}            - Отправить от имени хоста         │")
        print(f"│ {Fore.GREEN}mode <rcon|local>{Style.RESET_ALL}{Fore.YELLOW}      - Сменить режим отправки           │")
        print(f"│ {Fore.GREEN}rcon <cmd>{Style.RESET_ALL}{Fore.YELLOW}            - Сырая RCON команда               │")
        print(f"│ {Fore.GREEN}status{Style.RESET_ALL}{Fore.YELLOW}               - Статус системы                  │")
        print(f"│ {Fore.GREEN}cleanup [days]{Style.RESET_ALL}{Fore.YELLOW}         - Удалить неактивные устройства     │")
        print(f"│ {Fore.GREEN}help{Style.RESET_ALL}{Fore.YELLOW}                  - Эта справка                      │")
        print(f"│ {Fore.GREEN}exit/quit{Style.RESET_ALL}{Fore.YELLOW}             - Выход                            │")
        print(f"└────────────────────────────────────────────────┘{Style.RESET_ALL}\n")
        print(f"{Fore.CYAN}Режимы:{Style.RESET_ALL}")
        print(f"  {Fore.GREEN}RCON{Style.RESET_ALL}  — Через сервер (enable-rcon=true). Работает в фоне.")
        print(f"  {Fore.GREEN}LOCAL{Style.RESET_ALL} — Эмуляция клавиатуры (T → текст → Enter). Нужен клиент MC на ПК.\n")


console = Console()